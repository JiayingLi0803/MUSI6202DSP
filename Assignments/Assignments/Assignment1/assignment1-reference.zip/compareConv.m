function [m, mabs, stdev, time] = compareConv(x, h)
    %% Input Validation
    assert(iscolumn(x), 'x must be a column vector');
    assert(iscolumn(h), 'h must be a column vector');

    %% ADD YOUR CODE HERE
    tic;
    y_time = myTimeConv(x, h);
    t_time = toc;

    tic;
    y_freq = myFreqConv(x, h);
    t_freq = toc;
    
    tic;
    y_conv = conv(x, h);
    t_conv = toc;

    diff = ([y_freq, y_time] - y_conv).';
    m = mean(diff, 2);
    mabs = mean(abs(diff), 2);
    stdev = std(diff, 0, 2);

    time = [t_time; t_freq; t_conv];

    %%% END OF YOUR CODE
    %% Output Validation
    assert(all(size(m) == [2, 1]));
    assert(all(size(mabs) == [2, 1]));
    assert(all(size(stdev) == [2, 1]));
    assert(all(size(time) == [3, 1]));
end
