function y = myTimeConv(x, h)
% myTimeConv    Perform discrete convolution in time domain.
%   y = myTimeConv(x, h)  computes the convolution between x and h.

    %% Input Validation
    assert(iscolumn(x), 'x must be a column vector');
    assert(iscolumn(h), 'h must be a column vector');

    %% ADD YOUR CODE HERE
    m = length(x);
    n = length(h);
    
    % compute conv output length
    l = m + n - 1;

    % allocate array
    y = zeros(l,1);

    for k = 1:l
        % vectorize for speed
        i = max(1,k+1-n):min(k,m);
        y(k) = sum(x(i) .* h(k-i+1)); % same as x(i).' * h(k-i+1)
    end
    
    %%% END OF YOUR CODE
    %% Output Validation
    assert(iscolumn(y), 'y must be a column vector');
end