function y = myFreqConv(x, h)
% myTimeConv    Perform discrete convolution in time domain.
%   y = myTimeConv(x, h)  computes the convolution between x and h.

    %% Input Validation
    assert(iscolumn(x), 'x must be a column vector');
    assert(iscolumn(h), 'h must be a column vector');

    %% ADD YOUR CODE HERE
    m = length(x);
    n = length(h);
    l = m + n - 1;
    
    % compute the fft size needed
    lpad = 2.^nextpow2(l);
    
    % perform padding (no longer necessary)
    % xpad = [x; zeros(lpad-m, 1)];
    % hpad = [h; zeros(lpad-n, 1)];
    
    % fft now has automatic padding
    X = fft(x, lpad);
    H = fft(h, lpad);

    % freq domain conv
    Y = X .* H;

    % inverse fft and trim
    y = real(ifft(Y));
    y = y(1:l);

    %%% END OF YOUR CODE
    %% Output Validation
    assert(iscolumn(y), 'y must be a column vector');
end